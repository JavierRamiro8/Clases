var nom = document.getElementById('nombre');
var icon = document.getElementById('icono');

nom.addEventListener('input', function() {
    
    if(validarNombre(nom.value)) {
        nom.className = "verde";
        icon.className= "fa fa-check verde";
    } else {
        nom.className="fa fa-check rojo";
        icon.className= "fa fa-check rojo";
    }
});
        
     function validarNombre(nombre) {
         var re = /[a-zA-Z0-9_\s]+/;
        return re.test(nombre);
    }
