package main;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Persona p1 = new Persona("Ander");
		System.out.println(p1.getNombre());
		
		System.out.println(p1.getEdad());
		p1.setEdad(5);
		System.out.println(p1.getEdad());
	}

}
