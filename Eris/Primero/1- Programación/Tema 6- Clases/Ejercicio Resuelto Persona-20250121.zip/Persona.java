package main;

public class Persona {
	private String nombre;
	private int edad;
	private float estatura;
	private final String DNI;

	public Persona(String nombre, int edad, float estatura, String DNI) {
		this.nombre = nombre;
		this.edad = edad;
		this.estatura = estatura;
		this.DNI = DNI;
	}

	public Persona(String nombre) {
		this(nombre, 0, 1.0f, "00000000F");
	}

	public void crecer() {
		edad++;
	}

	public void saludar() {
		System.out.println("Hola!!");
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		if (edad >= 0) {
			this.edad = edad;
		} else {
			System.out.println("La edad no puede ser negativa!");
		}
	}

	public float getEstatura() {
		return estatura;
	}

	public void setEstatura(float estatura) {
		this.estatura = estatura;
	}

	public String getDNI() {
		return DNI;
	}

}
