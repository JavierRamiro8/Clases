package controlador;

import modelo.EmpleadoCompleto;
import modelo.EmpleadoParcial;

public class Main {

	public static void main(String[] args) {
		
		EmpleadoCompleto c1 = new EmpleadoCompleto("Ana", 1, 1000, 20);
		EmpleadoParcial p1 = new EmpleadoParcial("Juan", 2, 20, 10);
		
		c1.CalcularSalario(1000, 20);
		p1.CalcularSalario(20, 10);

	}

}
