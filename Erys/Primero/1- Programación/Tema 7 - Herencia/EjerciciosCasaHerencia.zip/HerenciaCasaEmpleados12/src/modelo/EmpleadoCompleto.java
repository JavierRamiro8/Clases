package modelo;

public class EmpleadoCompleto extends Empleado {
	private int horasExtra;
	

	public EmpleadoCompleto(String nombre, int codigoEmpleado, double salarioBase, int horasExtra) {
		super(nombre, codigoEmpleado, salarioBase);
		this.horasExtra = horasExtra;
	}


@Override
	public void CalcularSalario(int salarioBase, int horasExtra) {
		int salario = salarioBase + (salarioBase * horasExtra);
		System.out.println(salario);
		
	}




	
	
	
	

}
