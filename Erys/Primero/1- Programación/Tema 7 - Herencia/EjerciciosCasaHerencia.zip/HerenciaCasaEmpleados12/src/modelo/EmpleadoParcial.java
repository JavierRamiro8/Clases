package modelo;

import java.util.Arrays;
import java.util.Scanner;

public class EmpleadoParcial extends Empleado {

private int horasTrabajadas;

public EmpleadoParcial(String nombre, int codigoEmpleado, double salarioBase, int horasTrabajadas) {
	super(nombre, codigoEmpleado, salarioBase);
	this.horasTrabajadas = horasTrabajadas;
}


@Override
public void CalcularSalario(int salarioBase, int horasTrabajadas) {
	int salario = salarioBase + (salarioBase * horasTrabajadas);
	System.out.println(salario);
	
}


}



