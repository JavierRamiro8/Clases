package modelo;

public abstract class Empleado {
protected String nombre;
protected int codigoEmpleado;
protected double salarioBase;



public Empleado(String nombre, int codigoEmpleado, double salarioBase) {
	this.nombre = nombre;
	this.codigoEmpleado = codigoEmpleado;
	this.salarioBase = salarioBase;
}

public abstract void CalcularSalario(int salarioBase, int horasExtra);

}
