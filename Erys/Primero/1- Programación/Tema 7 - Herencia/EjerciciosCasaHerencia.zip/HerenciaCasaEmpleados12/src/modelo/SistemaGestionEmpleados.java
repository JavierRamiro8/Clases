package modelo;

import java.util.Arrays;

public class SistemaGestionEmpleados {
private Empleado[] empleadosArray;

public SistemaGestionEmpleados() {
	empleadosArray = new Empleado[0];
}


public void AnadirEmpleado(Empleado emp) {
	empleadosArray = Arrays.copyOf(empleadosArray, empleadosArray.length + 1);
	for(Empleado empleado: empleadosArray) {
		empleadosArray[empleadosArray.length-1] = empleado;
	}
	
	
}

public void CalcularMostrarSalario() {
	for (Empleado empleado: empleadosArray) {
		empleado.CalcularSalario(1000, 30);
		
	}
}
}
