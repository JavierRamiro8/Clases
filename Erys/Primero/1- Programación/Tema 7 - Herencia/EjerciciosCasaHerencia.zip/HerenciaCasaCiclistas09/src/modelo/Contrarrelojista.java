package modelo;

public class Contrarrelojista extends Ciclista {
private int velocidadMaxima;

public Contrarrelojista(int id, String nombre, int tiempoCarrera, int velocidadMaxima) {
	super(id, nombre, tiempoCarrera);
	this.velocidadMaxima = velocidadMaxima;
}

public int getVelocidadMaxima() {
	return velocidadMaxima;
}

public void setVelocidadMaxima(int velocidadMaxima) {
	this.velocidadMaxima = velocidadMaxima;
}

@Override
protected void imprimirDatos() {
	System.out.println(super.getId());
	System.out.println(super.getNombre());
	System.out.println(super.getTiempoCarrera());
	System.out.println(velocidadMaxima);

	
	
}

@Override
protected String imprimirTipo() {
	String cad = "Es un contrarrelojista";
	
	return cad;
	
}


}
