package modelo;

public class Escalador extends Ciclista {
private float aceleracionPromedio;
private float gradosRampa;
public Escalador(int id, String nombre, int tiempoCarrera, float aceleracionPromedio, float gradosRampa) {
	super(id, nombre, tiempoCarrera);
	this.aceleracionPromedio = aceleracionPromedio;
	this.gradosRampa = gradosRampa;
}
public float getAceleracionPromedio() {
	return aceleracionPromedio;
}
public void setAceleracionPromedio(float aceleracionPromedio) {
	this.aceleracionPromedio = aceleracionPromedio;
}
public float getGradosRampa() {
	return gradosRampa;
}
public void setGradosRampa(float gradosRampa) {
	this.gradosRampa = gradosRampa;
}
@Override
protected void imprimirDatos() {
	System.out.println(super.getId());
	System.out.println(super.getNombre());
	System.out.println(super.getTiempoCarrera());
	System.out.println(aceleracionPromedio);
	System.out.println(gradosRampa);
	
}

@Override
protected String imprimirTipo() {
	String cad = "Es un escalador";
	
	return cad;
	
}


}
