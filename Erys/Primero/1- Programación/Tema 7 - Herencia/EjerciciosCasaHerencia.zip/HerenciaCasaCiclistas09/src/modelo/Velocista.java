package modelo;

public class Velocista extends Ciclista {

private double potencia;
private double velocidadSprint;

public Velocista(int id, String nombre, int tiempoCarrera, double potencia, double velocidadSprint) {
	super(id, nombre, tiempoCarrera);
	this.potencia = potencia;
	this.velocidadSprint = velocidadSprint;
}

public double getPotencia() {
	return potencia;
}

public void setPotencia(double potencia) {
	this.potencia = potencia;
}

public double getVelocidadSprint() {
	return velocidadSprint;
}

public void setVelocidadSprint(double velocidadSprint) {
	this.velocidadSprint = velocidadSprint;
}

@Override
protected void imprimirDatos() {
	System.out.println(super.getId());
	System.out.println(super.getNombre());
	System.out.println(super.getTiempoCarrera());
	System.out.println(potencia);
	System.out.println(velocidadSprint);
	
}

@Override
protected String imprimirTipo() {
	String cad = "Es un velocista";
	
	return cad;
	
}

}
