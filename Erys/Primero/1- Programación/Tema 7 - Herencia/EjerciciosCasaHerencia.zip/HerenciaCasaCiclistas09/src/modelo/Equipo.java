package modelo;

import java.util.Arrays;
import java.util.Scanner;

public class Equipo {
private String nombre;
private int sumaTiempos;
private String pais;
private Ciclista[] CiclistasEquipo;



public Equipo(String nombre, int sumaTiempos, String pais) {
	this.nombre = nombre;
	this.sumaTiempos = sumaTiempos;
	this.pais = pais;
	CiclistasEquipo = new Ciclista[0];
}




protected void imprimirDatos() {
	System.out.println(nombre);
	System.out.println(sumaTiempos);
	System.out.println(pais);
}



protected String getNombre() {
	return nombre;
}

protected void setNombre(String nombre) {
	this.nombre = nombre;
}

protected int getSumaTiempos() {
	return sumaTiempos;
}

protected void setSumaTiempos(int sumaTiempos) {
	this.sumaTiempos = sumaTiempos;
}

protected String getPais() {
	return pais;
}

protected void setPais(String pais) {
	this.pais = pais;
}

protected Ciclista[] getCiclistasEquipo() {
	return CiclistasEquipo;
}

protected void setCiclistasEquipo(Ciclista[] ciclistasEquipo) {
	CiclistasEquipo = ciclistasEquipo;
}

public void AnadirCiclista(Ciclista ciclista) {

	CiclistasEquipo = Arrays.copyOf(CiclistasEquipo, CiclistasEquipo.length + 1);
	CiclistasEquipo[CiclistasEquipo.length - 1] = ciclista;
	CalcularTiempo();
}


protected void CalcularTiempo() {
	for(Ciclista ciclista: CiclistasEquipo) {
		sumaTiempos += ciclista.getTiempoCarrera(); 
}

}

protected void ListarNombres() {
	for (Ciclista ciclista: CiclistasEquipo) {
		System.out.println(ciclista.getNombre());
	}
	

}

protected void MostrarDatosCiclista() {
	Scanner sc = new Scanner(System.in);
	int id = sc.nextInt();
	for (Ciclista ciclista: CiclistasEquipo) {
		if (id != 0) {
			System.out.println(ciclista.getNombre());
			System.out.println(ciclista.getId());
			System.out.println(ciclista.getTiempoCarrera());
			
		} else {
			System.out.println("El ciclista no existe");
		}
	}
}
}
