package controlador;

import modelo.Equipo;
import modelo.Velocista;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Velocista v1 = new Velocista(50, "Alguien", 100, 50, 70);
		Equipo e1 = new Equipo("asdf", 0, "España");
		v1.setTiempoCarrera(20);
		e1.AnadirCiclista(v1);
	
		
	}

	
}
