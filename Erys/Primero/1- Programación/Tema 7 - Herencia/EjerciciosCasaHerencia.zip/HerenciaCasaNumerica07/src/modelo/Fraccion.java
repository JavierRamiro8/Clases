package modelo;

public class Fraccion extends Numerica {
private int numerador;
private int denominador;

	

public Fraccion(int numerador, int denominador) {
	super();
	this.numerador = numerador;
	this.denominador = denominador;
}

public int getNumerador() {
	return numerador;
}

public void setNumerador(int numerador) {
	this.numerador = numerador;
}

public int getDenominador() {
	return denominador;
}

public void setDenominador(int denominador) {
	this.denominador = denominador;
}

@Override
public String toString() {
	String num1 = Integer.toString(numerador);
	String num2 = Integer.toString(denominador);
	return num1 + " / " + num2;
}


@Override
public boolean equals(Object ob) { //compara this con otro
Fraccion fr = (Fraccion) ob; //este cast se explica más abajo
 boolean iguales;
 if (this.numerador == ((Fraccion) ob).getNumerador() && this.denominador ==
 ((Fraccion) ob).getDenominador()) {
 iguales = true;
 } else {
 iguales = false;

 }
return iguales;}

@Override
public Numerica sumar(Numerica número) {
	Fraccion otraFraccion = (Fraccion) número;
    int numResultado = this.numerador + otraFraccion.numerador;
    int denResultado = this.denominador * otraFraccion.denominador;
    return new Fraccion(numResultado, denResultado);
}

@Override
public Numerica restar(Numerica número) {
	Fraccion otraFraccion = (Fraccion) número;
    int numResultado = this.numerador - otraFraccion.numerador;
    int denResultado = this.denominador * otraFraccion.denominador;
    return new Fraccion(numResultado, denResultado);
}

@Override
public Numerica multiplicar(Numerica número) {
	Fraccion otraFraccion = (Fraccion) número;
    int numResultado = this.numerador * otraFraccion.numerador;
    int denResultado = this.denominador * otraFraccion.denominador;
    return new Fraccion(numResultado, denResultado);
}

@Override
public Numerica dividir(Numerica número) {
	Fraccion otraFraccion = (Fraccion) número;
    int numResultado = this.numerador * otraFraccion.denominador;
    int denResultado = this.denominador * otraFraccion.numerador;
    return new Fraccion(numResultado, denResultado);
}

}
