package modelo;

public class Jugador extends Persona {
	
	private int dorsal;
	private String demarcacion;
	
	public Jugador(int id, String nombre, String apellidos, int edad, int dorsal, String demarcacion) {
		super(id, nombre, apellidos, edad);
		this.dorsal = dorsal;
		this.demarcacion = demarcacion;
	}
	
public void jugarPartido(){
		
	};
	
public void entrenar(){
		
	};
	

}
