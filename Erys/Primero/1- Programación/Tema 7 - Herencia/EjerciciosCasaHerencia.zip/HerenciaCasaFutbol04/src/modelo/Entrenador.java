package modelo;

public class Entrenador extends Persona {
	private String idFederacion;

	public Entrenador(int id, String nombre, String apellidos, int edad, String idFederacion) {
		super(id, nombre, apellidos, edad);
		this.idFederacion = idFederacion;
	}

	public void dirigirPartido(){
		
	};
	
public void dirigirEntrenamiento(){
		
	};
}
