package modelo;

public class Gato extends Felino {

	public String getNombreCientifico() {
		return "Felis silvestris catus";
		
	}
	
	public String getAlimentos() {
		return "ratones";
		
	}
	
	public String getSonido() {
		return "maullido";
		
	}
	
	public String getHabitat() {
		return "doméstico";
		
	}
}
