package modelo;

public class Leon extends Felino {

	public String getNombreCientifico() {
		return "panthera leo";
		
	}
	
	public String getAlimentos() {
		return "carnívoro";
		
	}
	
	public String getSonido() {
		return "rugido";
		
	}
	
	public String getHabitat() {
		return "pradera";
		
	}

}
