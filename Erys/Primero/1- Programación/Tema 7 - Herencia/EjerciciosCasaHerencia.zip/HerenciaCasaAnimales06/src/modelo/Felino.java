package modelo;

public abstract class Felino extends Animal{

}
