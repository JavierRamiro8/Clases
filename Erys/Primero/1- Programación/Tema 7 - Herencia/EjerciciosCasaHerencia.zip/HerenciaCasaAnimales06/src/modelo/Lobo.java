package modelo;

public class Lobo extends Canido {

	public String getNombreCientifico() {
		return "canis lupus";
		
	}
	
	public String getAlimentos() {
		return "carnívoro";
		
	}
	
	public String getSonido() {
		return "aullido";
		
	}
	
	public String getHabitat() {
		return "bosque";
		
	}

}
