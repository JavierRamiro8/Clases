package modelo;

public abstract class Animal {
protected String sonido;
protected String alimento;
protected String habitat;
protected String nombreCientifico;

public Animal(){
    sonido = "";
    alimento = "";
    habitat = "";
    nombreCientifico = "";
}

public Animal(String sonido, String alimento, String habitat, String nombreCientifico) {
	this.sonido = sonido;
	this.alimento = alimento;
	this.habitat = habitat;
	this.nombreCientifico = nombreCientifico;
}


public abstract String getNombreCientifico();
public abstract String getSonido();
public abstract String getAlimentos();
public abstract String getHabitat();

@Override

public String toString() {
    return "Sonido: " + getSonido() + ", alimento: " + getAlimentos() + ", habitat " + getHabitat() + ", nombreCientifico " + getNombreCientifico();
}
}



