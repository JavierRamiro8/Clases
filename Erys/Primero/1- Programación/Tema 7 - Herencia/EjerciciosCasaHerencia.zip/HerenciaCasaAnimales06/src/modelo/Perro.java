package modelo;

public class Perro extends Canido {

	public String getNombreCientifico() {
		return "canis lupus familiaris";
		
	}
	
	public String getAlimentos() {
		return "carnívoro";
		
	}
	
	public String getSonido() {
		return "ladrido";
		
	}
	
	public String getHabitat() {
		return "doméstico";
		
	}

}
