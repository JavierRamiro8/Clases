package modelo;

public abstract class Canido extends Animal {

}
