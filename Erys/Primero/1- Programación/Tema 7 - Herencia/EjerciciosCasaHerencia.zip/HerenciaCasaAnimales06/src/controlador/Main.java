package controlador;

import java.util.Arrays;

import modelo.Animal;
import modelo.Gato;
import modelo.Leon;
import modelo.Lobo;
import modelo.Perro;

public class Main {

	public static void main(String[] args) {
		Perro p = new Perro();
		Gato g = new Gato();
		Lobo lo = new Lobo();
		Leon le = new Leon();
		
		Animal [] a = new Animal [4];
		a[0] = p;
		a[1] = g;
		a[2] = lo;
		a[3] = le;
		
		System.out.println(Arrays.toString(a));
		

	}

}
