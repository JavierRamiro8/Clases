package modelo;

public class Actor {
private String actor;


}
