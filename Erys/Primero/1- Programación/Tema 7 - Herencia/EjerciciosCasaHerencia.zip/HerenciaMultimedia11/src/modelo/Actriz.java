package modelo;

public class Actriz {
private String actriz;
	public Actriz() {
		// TODO Auto-generated constructor stub
	}

}
