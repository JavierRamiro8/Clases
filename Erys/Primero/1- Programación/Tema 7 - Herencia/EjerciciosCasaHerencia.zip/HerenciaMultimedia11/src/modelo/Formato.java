package modelo;

public enum Formato {
	wav, mp3, midi, avi, mov, mpg, cdAudio, dvd
}
