package modelo;

public class Pelicula extends Multimedia {

	private Actor actor;
	private Actriz actriz;
	
	
	public Pelicula(String titulo, String autor, float duracion, Formato formato, Actor actor, Actriz actriz) {
		super(titulo, autor, duracion, formato);
		this.actor = actor;
		this.actriz = actriz;
	}
	
	public Pelicula(String titulo, String autor, float duracion, Formato formato, Actriz actriz) {
		super(titulo, autor, duracion, formato);
		this.actriz = actriz;
	}

	public Pelicula(String titulo, String autor, float duracion, Formato formato, Actor actor) {
		super(titulo, autor, duracion, formato);
		this.actor = actor;
	}

	public Actor getActor() {
		return actor;
	}

	public void setActor(Actor actor) {
		this.actor = actor;
	}

	public Actriz getActriz() {
		return actriz;
	}

	public void setActriz(Actriz actriz) {
		this.actriz = actriz;
	}
	
	public String toString() {
		String cad = "Autor: " + getAutor() + " Titulo: " + getTitulo() + " Formato: " + getFormato() + " Duracion: " + getDuracion() + " Actor: " + getActor() + " Actriz: " + getActriz();
		return cad;
		
	}

}
