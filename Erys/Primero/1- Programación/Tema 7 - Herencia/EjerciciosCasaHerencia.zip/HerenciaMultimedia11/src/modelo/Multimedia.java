package modelo;

public class Multimedia {
protected String titulo;
protected String autor;
protected float duracion;
protected Formato formato;

	public Multimedia(String titulo, String autor, float duracion, Formato formato) {
	this.titulo = titulo;
	this.autor = autor;
	this.duracion = duracion;
	this.formato = formato;
}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public float getDuracion() {
		return duracion;
	}

	public void setDuracion(float duracion) {
		this.duracion = duracion;
	}

	public Formato getFormato() {
		return formato;
	}

	public void setFormato(Formato formato) {
		this.formato = formato;
	}

	public String toString() {
		String cad = "Autor: " + getAutor() + " Titulo: " + getTitulo() + " Formato: " + getFormato() + " Duracion: " + getDuracion();
		return cad;
		
	}
	
	public void equals(Multimedia otra) {
		boolean iguales;
		
		if (this.titulo == otra.titulo && this.autor == otra.autor) {
			iguales = true;
		} else {
			iguales = false;
		}
	}
}
