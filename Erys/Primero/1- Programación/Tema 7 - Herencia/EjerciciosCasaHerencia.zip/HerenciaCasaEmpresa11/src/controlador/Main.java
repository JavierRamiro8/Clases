package controlador;

import modelo.Empleado;
import modelo.Jefe;
import modelo.Secretario;
import modelo.Vendedor;

public class Main {

	public static void main(String[] args) {

		// Constructor de Vendedor
		Vendedor v = new Vendedor(
		    "Juan", "Pérez López", "12345678A", "Calle Falsa 123, Madrid",
		    912345678, 25000, "Ford Focus", 620123456, 
		    "Madrid Centro", "Empresa1, Empresa2, Empresa3", 5.5f
		);

		// Constructor de Secretario
		Secretario s = new Secretario(
		    "María", "Gómez Fernández", "87654321B", "Av. Principal 45, Barcelona",
		    932145678, 22000, 101, 932145670
		);

		// Constructor de Jefe
		Jefe j = new Jefe(
		    "Carlos", "López García", "11223344C", "Plaza Mayor 12, Valencia",
		    961234567, 50000, "BMW X5", 
		    "Oficina 301", s, "Vendedor1, Vendedor2, Vendedor3"
		);

		v.incrementarSalario(1000);
		s.incrementarSalario(1500);
		j.incrementarSalario(2000);
		
		
		
	}

}
