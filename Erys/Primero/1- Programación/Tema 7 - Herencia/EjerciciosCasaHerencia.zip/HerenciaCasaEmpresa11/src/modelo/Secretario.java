package modelo;

public class Secretario extends Empleado {
	private int despacho;
	private int fax;
	
	public Secretario(String nombre, String apellidos, String dni, String direccion, int telefono, int salario,
			int despacho, int fax) {
		super(nombre, apellidos, dni, direccion, telefono, salario);
		this.despacho = despacho;
		this.fax = fax;
	}

	@Override
	public void imprimir() {
		super.imprimir();
		System.out.println(despacho);
		System.out.println(fax);
		System.out.println("Secretario");
	}

	@Override
	public void incrementarSalario(int salario) {
		int nuevoSalario = salario + (int) (salario * 0.10);
		System.out.println(nuevoSalario);
		
	}

	
	
	
	

}
