package modelo;

public class Jefe extends Empleado {
	private String coche;
private String despacho;
private Secretario secretario;
private String ListaVendedores;

public Jefe(String nombre, String apellidos, String dni, String direccion, int telefono, int salario, String coche,
		String despacho, Secretario secretario, String listaVendedores) {
	super(nombre, apellidos, dni, direccion, telefono, salario);
	this.coche = coche;
	this.despacho = despacho;
	this.secretario = secretario;
	ListaVendedores = listaVendedores;
}

public String getDespacho() {
	return despacho;
}

public void setDespacho(String despacho) {
	this.despacho = despacho;
}

public Secretario getSecretario() {
	return secretario;
}

public void setSecretario(Secretario secretario) {
	this.secretario = secretario;
}

public String getListaVendedores() {
	return ListaVendedores;
}

public void setListaVendedores(String listaVendedores) {
	ListaVendedores = listaVendedores;
}

public String getCoche() {
	return coche;
}

@Override
public void incrementarSalario(int salario) {
	int nuevoSalario = salario + (int) (salario * 0.20);
	System.out.println(nuevoSalario);
	
}

@Override
public void imprimir() {
	super.imprimir();
	System.out.println(despacho);
	System.out.println(coche);
	System.out.println(ListaVendedores);
	System.out.println("Jefe");
}

public void cambiarCoche(String otroCoche) {
	setCoche(otroCoche);
}

private void setCoche(String otroCoche) {
	this.coche = coche;
	
}


}
