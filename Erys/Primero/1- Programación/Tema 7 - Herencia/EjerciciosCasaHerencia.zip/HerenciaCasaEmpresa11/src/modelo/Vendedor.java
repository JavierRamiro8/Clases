package modelo;

import java.util.Arrays;
import java.util.Scanner;

public class Vendedor extends Empleado {

private String coche;
private int movil;
private String areaVenta;
private String clientes;
private float comision;


public Vendedor(String nombre, String apellidos, String dni, String direccion, int telefono, int salario, String coche,
		int movil, String areaVenta, String clientes, float comision) {
	super(nombre, apellidos, dni, direccion, telefono, salario);
	this.coche = coche;
	this.movil = movil;
	this.areaVenta = areaVenta;
	this.clientes = clientes;
	this.comision = comision;
}


public String getCoche() {
	return coche;
}


public void setCoche(String coche) {
	this.coche = coche;
}


public int getMovil() {
	return movil;
}


public void setMovil(int movil) {
	this.movil = movil;
}


public String getAreaVenta() {
	return areaVenta;
}


public void setAreaVenta(String areaVenta) {
	this.areaVenta = areaVenta;
}


public String getClientes() {
	return clientes;
}


public void setClientes(String nuevoCliente) {
	this.clientes = nuevoCliente;
}


public float getComision() {
	return comision;
}


public void setComision(float comision) {
	this.comision = comision;
}


public void imprimir() {
	super.imprimir();
	System.out.println(coche);
	System.out.println(movil);
	System.out.println(areaVenta);
	System.out.println(clientes);
	System.out.println("Vendedor");
}


@Override
public void incrementarSalario(int salario) {
	int nuevoSalario = salario + (int) (salario * 0.05);
	System.out.println(nuevoSalario);
	
}

public void AltaCliente() {
	Scanner sc = new Scanner(System.in);
	String nuevoCliente = sc.nextLine();
	setClientes(nuevoCliente);
}


public void BajaCliente() {
	setClientes("");
}

public void cambiarCoche(String otroCoche) {
	setCoche(otroCoche);
}

}



