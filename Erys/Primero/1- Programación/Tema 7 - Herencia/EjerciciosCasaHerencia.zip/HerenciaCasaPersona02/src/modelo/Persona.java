package modelo;

import java.security.interfaces.DSAKeyPairGenerator;
import java.util.Random;

public class Persona {
	private String nombre;
	private int edad;
	private int CI;
	private int peso;
	private float altura;
	private sexo sexo;

	public Persona(String nombre, int edad, int CI, int peso, float altura, sexo sexo) {
		this.nombre = nombre;
		this.edad = edad;
		this.CI = CI;
		this.peso = peso;
		this.altura = altura;
		this.sexo = sexo;
	}
	
	public Persona() {
		nombre = "";
		edad = 0;
		CI = 0;
		peso = 0;
		altura = 0;
		sexo = null;

}

public Persona(String nombre, int edad, sexo sexo) {
	this.nombre = nombre;
	this.edad = edad;
	CI = 0;
	peso = 0;
	altura = 0;
	this.sexo = sexo;
}

public void calcularIMC(int peso, float altura) {
	int imc = (int) ((int) peso / Math.pow(altura, 2));
	
	if (imc > peso ) {
		System.out.println("1");
	} else if (imc == peso) {
		System.out.println("0");
	} else {
		System.out.println("-1");
	}
}

public boolean esMayorDeEdad(int edad) {
	if (edad > 18) {
		return true;
	}
	return false;
}

public void comprobarSexo(sexo sexo) {
	switch(sexo) {
	case H:
		System.out.println("Es correcto");
		break;
	case M:
		System.out.println("Es correcto");
		break;
		default:
		System.out.println("H");
		break;
	}}		
protected void generaCI() {
	Random rand = new Random();
		int CI = rand.nextInt(1, 1000000000);
};

};