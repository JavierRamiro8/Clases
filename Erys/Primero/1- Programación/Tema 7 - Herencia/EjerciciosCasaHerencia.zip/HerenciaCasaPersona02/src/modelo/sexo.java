package modelo;

public enum sexo {
H, M;
}
