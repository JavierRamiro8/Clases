package modelo;

public class Television extends Electrodomestico {
	int resolucion = 20;
	boolean sintonizador = false;

	public Television(float precio, String color, char consumoEnergetico, int peso, int resolucion, boolean sintonizador) {
		super(precio, color, consumoEnergetico, peso);
		this.resolucion = resolucion;
		this.sintonizador = sintonizador;

	}

public Television(float precio, int peso) {
	super(precio, peso);
	this.precio = precio;
	color = "blanco";
	consumoEnergetico = 'A';
	peso = 50;
}

	
public int getResolucion(int resolucion) {
	return resolucion;
}

public boolean getSintonizador(boolean sintonizador) {
	return sintonizador;
}

public void precioFinal(int resolucion, boolean sintonizador) {
	if (resolucion > 40) {
		super.precio = (float) super.precio + 0.3f;
	} else if (sintonizador == true) {
		super.precio = (float) super.precio + 50;
	}
}

}



