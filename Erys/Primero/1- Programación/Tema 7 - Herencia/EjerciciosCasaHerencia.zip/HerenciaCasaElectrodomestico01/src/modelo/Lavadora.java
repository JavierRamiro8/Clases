package modelo;

public class Lavadora extends Electrodomestico {
	final int carga = 5;

	public Lavadora(int carga) {
		super(carga);

	}

public Lavadora(float precio, int peso) {
	super(precio, peso);
	this.precio = precio;
	color = "blanco";
	consumoEnergetico = 'A';
	peso = 300;
}
public Lavadora(float precio, String color, char consumoEnergetico, int peso, int carga) {
	super(precio, color, consumoEnergetico, peso);
}
	
public int getCarga(int carga) {
	return carga;
}

public void precioFinal(int carga) {
	if (carga > 30) {
		super.precio = super.precio + 50;
	}
}

}



