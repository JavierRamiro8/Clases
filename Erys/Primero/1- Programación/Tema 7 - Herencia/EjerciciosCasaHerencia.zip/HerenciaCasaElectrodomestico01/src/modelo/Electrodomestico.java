package modelo;

import java.util.Scanner;

public class Electrodomestico {
	float precio;
	String color;
	char consumoEnergetico;
	int peso;

	public Electrodomestico(float precio, String color, char consumoEnergetico, int peso) {
		this.precio = precio;
		this.color = color;
		this.consumoEnergetico = consumoEnergetico;
		this.peso = peso;
	}

	public Electrodomestico(float precio, int peso) {
		this.precio = precio;
		this.peso = peso;
	}

	public Electrodomestico(int carga) {
		// TODO Auto-generated constructor stub
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public char getConsumoEnergetico() {
		return consumoEnergetico;
	}

	public void setConsumoEnergetico(char consumoEnergetico) {
		this.consumoEnergetico = consumoEnergetico;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	private void comprobarConsumoEnergetico(char letra) {
		switch (letra) {
		case 'A', 'B', 'C', 'D', 'E', 'F':
			System.out.println("Letra correcta");
			break;
		default:
			letra = 'A';
			break;
		}
	}

	private void comprobarColor(String color) {
		switch (color) {
		case "Blanco", "Negro", "Plateado":
			System.out.println("Color correcto");
			break;
		default:
			color = "Blanco";
			break;
		}
	}

	protected void precio(char letra) {
		float precio = 0;
		switch(letra) {
		case 'A', 'B', 'C':
			precio = 3000f;
		break;
		case 'D', 'E':
			precio = 1000f;
		break;
		case 'F':
			precio = 500f;
			break;
		default:
			precio = 3000f;
		}
	}
}
