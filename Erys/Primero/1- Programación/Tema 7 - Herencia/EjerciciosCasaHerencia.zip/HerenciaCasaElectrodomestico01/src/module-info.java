/**
 * 
 */
/**
 * 
 */
module HerenciaCasaElectrodomestico01 {
}