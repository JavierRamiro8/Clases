package modelo;

public class PCongeladoNitrogeno extends Producto{
private String metodoCongelacion;
private int tiempoExpo;

public PCongeladoNitrogeno(String fechaCaducidad, int numLote, String metodoCongelacion, int tiempoExpo) {
	super(fechaCaducidad, numLote);
	this.metodoCongelacion = metodoCongelacion;
	this.tiempoExpo = tiempoExpo;
}


}
