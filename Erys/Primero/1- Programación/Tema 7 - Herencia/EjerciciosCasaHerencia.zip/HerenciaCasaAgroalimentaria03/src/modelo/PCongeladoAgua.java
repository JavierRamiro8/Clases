package modelo;

public class PCongeladoAgua extends Producto{
private int salinidad;

public PCongeladoAgua(String fechaCaducidad, int numLote, int salinidad) {
	super(fechaCaducidad, numLote);
	this.salinidad = salinidad;
}


}
