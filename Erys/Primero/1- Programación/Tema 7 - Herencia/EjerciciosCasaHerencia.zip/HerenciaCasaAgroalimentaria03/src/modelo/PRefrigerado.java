package modelo;

public class PRefrigerado extends Producto{
private int codOrg;
private String fechaEnvasado;
private String temperaturaRec;
private String pais;


public PRefrigerado(String fechaCaducidad, int numLote, int codOrg, String fechaEnvasado, String temperaturaRec,
		String pais) {
	super(fechaCaducidad, numLote);
	this.codOrg = codOrg;
	this.fechaEnvasado = fechaEnvasado;
	this.temperaturaRec = temperaturaRec;
	this.pais = pais;
}
}
