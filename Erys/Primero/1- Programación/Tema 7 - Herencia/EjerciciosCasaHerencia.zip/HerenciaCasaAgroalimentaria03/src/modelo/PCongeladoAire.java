package modelo;

public abstract class PCongeladoAire extends Producto {
private float nitrogeno;
private float agua;
private float c02;
private float oxigeno;

public PCongeladoAire(String fechaCaducidad, int numLote, float nitrogeno, float agua, float c02, float oxigeno) {
	super(fechaCaducidad, numLote);
	this.nitrogeno = nitrogeno;
	this.agua = agua;
	this.c02 = c02;
	this.oxigeno = oxigeno;
}


}
