package modelo;

public class Producto {
protected String fechaCaducidad;
protected int numLote;

public Producto(String fechaCaducidad, int numLote) {
	super();
	this.fechaCaducidad = fechaCaducidad;
	this.numLote = numLote;
}
public String getFechaCaducidad() {
	return fechaCaducidad;
}
public void setFechaCaducidad(String fechaCaducidad) {
	this.fechaCaducidad = fechaCaducidad;
}
public int getNumLote() {
	return numLote;
}
public void setNumLote(int numLote) {
	this.numLote = numLote;
}
}
