package modelo;

public class PFresco extends Producto {
	private String fechaEnvasado;
	private String pais;

	public PFresco(String fechaCaducidad, int numLote, String fechaEnvasado, String pais) {
		super(fechaCaducidad, numLote);
		this.fechaEnvasado = fechaEnvasado;
		this.pais = pais;
	}
}
