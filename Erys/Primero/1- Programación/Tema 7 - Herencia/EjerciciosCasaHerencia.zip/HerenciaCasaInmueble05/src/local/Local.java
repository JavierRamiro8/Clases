package local;

import modelo.Inmueble;

public abstract class Local extends Inmueble{


protected String localizacion;

public Local(int id, int area, String direccion, int valorCompra) {
	super(id, area, direccion, valorCompra);
	// TODO Auto-generated constructor stub
}


}
