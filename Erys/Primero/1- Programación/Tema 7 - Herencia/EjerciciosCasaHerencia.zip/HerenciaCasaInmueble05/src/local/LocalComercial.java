package local;

public class LocalComercial extends Local {
protected int centroComercial;

public LocalComercial(int id, int area, String direccion, int valorCompra, int centroComercial) {
	super(id, area, direccion, valorCompra);
	this.centroComercial = centroComercial;
}


public void precio(int area) {
	int precio = (int) (2000000 * area);
}

}
