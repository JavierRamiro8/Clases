package local;

public class Oficina extends Local {
	
	protected boolean esGobierno;

	public Oficina(int id, int area, String direccion, int valorCompra, boolean esGobierno) {
		super(id, area, direccion, valorCompra);
		this.esGobierno = esGobierno;
	}

	public void precio(int area) {
		int precio = (int) (3500000 * area);
	}
}
