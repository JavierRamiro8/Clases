package modelo;

public abstract class Inmueble {
protected int id;
protected int area;
protected String direccion;
protected int valorCompra;

public Inmueble(int id, int area, String direccion, int valorCompra) {
	this.id = id;
	this.area = area;
	this.direccion = direccion;
	this.valorCompra = valorCompra;
}

public void precio(int area) {
	int precio = this.valorCompra * this.area;
}

}
