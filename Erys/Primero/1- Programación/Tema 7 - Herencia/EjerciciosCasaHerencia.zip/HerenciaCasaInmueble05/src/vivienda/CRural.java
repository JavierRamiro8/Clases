package vivienda;

public class CRural extends Casa{

private int distMunicipal;
private int altitudMar;
public CRural(int id, int area, String direccion, int valorCompra, int habitaciones, int banyos, int numPisos,
		int distMunicipal, int altitudMar) {
	super(id, area, direccion, valorCompra, habitaciones, banyos, numPisos);
	this.distMunicipal = distMunicipal;
	this.altitudMar = altitudMar;
}

public void precio(int area) {
	int precio = (int) (1500000 * area);
}


}
