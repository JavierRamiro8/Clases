package vivienda;

public abstract class CUrbana extends Casa {

	public CUrbana(int id, int area, String direccion, int valorCompra, int habitaciones, int banyos, int numPisos) {
		super(id, area, direccion, valorCompra, habitaciones, banyos, numPisos);
		// TODO Auto-generated constructor stub
	}

	
	
	}

