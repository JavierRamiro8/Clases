package vivienda;

public class Casa extends Vivienda {
	protected int numPisos;

	public Casa(int id, int area, String direccion, int valorCompra, int habitaciones, int banyos, int numPisos) {
		super(id, area, direccion, valorCompra, habitaciones, banyos);
		this.numPisos = numPisos;
	}

	
	}

