package vivienda;

public class CUrbanaConjunto extends CUrbana {
private int valorAdmon;
private boolean areasComunes;
public CUrbanaConjunto(int id, int area, String direccion, int valorCompra, int habitaciones, int banyos, int numPisos,
		int valorAdmon, boolean areasComunes) {
	super(id, area, direccion, valorCompra, habitaciones, banyos, numPisos);
	this.valorAdmon = valorAdmon;
	this.areasComunes = areasComunes;
}

public void precio(int area) {
	int precio = (int) (2500000 * this.area);
}
}
