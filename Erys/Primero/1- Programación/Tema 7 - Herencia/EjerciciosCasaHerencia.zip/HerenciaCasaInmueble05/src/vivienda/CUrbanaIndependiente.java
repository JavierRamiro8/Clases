package vivienda;

public class CUrbanaIndependiente extends CUrbana {

	public CUrbanaIndependiente(int id, int area, String direccion, int valorCompra, int habitaciones, int banyos,
			int numPisos) {
		super(id, area, direccion, valorCompra, habitaciones, banyos, numPisos);
		// TODO Auto-generated constructor stub
	}
	
	public void precio(int area) {
		int precio = (int) (3000000 * this.area);
	}

}
