package vivienda;

import modelo.Inmueble;

public abstract class Vivienda extends Inmueble {
protected int habitaciones;
protected int banyos;

public Vivienda(int id, int area, String direccion, int valorCompra, int habitaciones, int banyos) {
	super(id, area, direccion, valorCompra);
	this.habitaciones = habitaciones;
	this.banyos = banyos;
}




}

