package apartamento;

import modelo.Inmueble;

public abstract class Apartamento extends Inmueble {
protected int valorAdmon;

public Apartamento(int id, int area, String direccion, int valorCompra) {
	super(id, area, direccion, valorCompra);
	// TODO Auto-generated constructor stub
}







}
