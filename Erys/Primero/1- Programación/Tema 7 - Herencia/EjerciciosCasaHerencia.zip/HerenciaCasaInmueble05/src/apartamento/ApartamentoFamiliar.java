package apartamento;

import modelo.Inmueble;

public abstract class ApartamentoFamiliar extends Apartamento {

	public ApartamentoFamiliar(int id, int area, String direccion, int valorCompra) {
		super(id, area, direccion, valorCompra);
	}

	public void precio(int area) {
		int precio = (int) (2000000 * area);
	}
}


