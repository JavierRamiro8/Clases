package apartamento;

public class apartaestudio extends Apartamento {

private int habitaciones = 1;

public apartaestudio(int id, int area, String direccion, int valorCompra, int habitaciones) {
	super(id, area, direccion, valorCompra);
	this.habitaciones = habitaciones;
}

public void precio(int area) {
	int precio = (int) (1500000 * this.area);
}
}


