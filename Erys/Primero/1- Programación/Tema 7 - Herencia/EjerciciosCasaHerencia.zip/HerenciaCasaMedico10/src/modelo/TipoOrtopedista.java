package modelo;

public enum TipoOrtopedista {
Pediatrico, maxilofacial
}
