package modelo;

public class Pediatra extends Medico {

	private TipoPediatra tipoPedi;

	public Pediatra(String nombre, TipoPediatra tipoPedi) {
		super(nombre);
		this.tipoPedi = tipoPedi;
	}

	public TipoPediatra getTipoPedi() {
		return tipoPedi;
	}

	public void setTipoPedi(TipoPediatra tipoPedi) {
		this.tipoPedi = tipoPedi;
	}
	
	

	

	

}
