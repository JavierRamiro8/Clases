package modelo;

public enum TipoPediatra {
Neurologo, Psicologo
}
