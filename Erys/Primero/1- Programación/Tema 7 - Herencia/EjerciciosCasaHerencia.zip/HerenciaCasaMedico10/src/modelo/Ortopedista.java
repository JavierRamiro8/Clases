package modelo;

public class Ortopedista extends Medico {

private TipoOrtopedista tipoOrtoped;

public Ortopedista(String nombre, TipoOrtopedista tipoOrtoped) {
	super(nombre);
	this.tipoOrtoped = tipoOrtoped;
}

public TipoOrtopedista getTipoOrtoped() {
	return tipoOrtoped;
}

public void setTipoOrtoped(TipoOrtopedista tipoOrtoped) {
	this.tipoOrtoped = tipoOrtoped;
}

}
