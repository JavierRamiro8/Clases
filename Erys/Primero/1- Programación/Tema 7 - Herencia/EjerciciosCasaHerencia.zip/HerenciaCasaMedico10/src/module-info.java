/**
 * 
 */
/**
 * 
 */
module HerenciaCasaMedico10 {
}