package controlador;

import java.util.Vector;

import modelo.Medico;
import modelo.Ortopedista;
import modelo.Pediatra;
import modelo.TipoOrtopedista;
import modelo.TipoPediatra;

public class Main {

	public static void main(String[] args) {
		
		Pediatra p1 = new Pediatra("Jimena", TipoPediatra.Psicologo);
		Pediatra p2 = new Pediatra("Garazi", TipoPediatra.Neurologo);
		Ortopedista o1 = new Ortopedista("Ana", TipoOrtopedista.Pediatrico);
		
		Vector<Medico> vec = new Vector<Medico>(5, 5);
		
		vec.addElement(o1);
		vec.addElement(p1);
		vec.addElement(p2);
		
		System.out.println(vec.indexOf(o1));
		System.out.println(vec.indexOf(p1));
		System.out.println(vec.indexOf(p2));
		
	}

}
