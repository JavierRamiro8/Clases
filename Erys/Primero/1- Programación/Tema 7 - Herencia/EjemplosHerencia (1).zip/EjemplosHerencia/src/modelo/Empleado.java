package modelo;

public class Empleado extends Persona {

	private int salario;
	private String estatura;
	
	public Empleado(String nombre, int edad, String estatura, int salario) {
		super(nombre,edad,0.0f);
		this.salario = salario;
		this.estatura = estatura;
	}
	
	public String getEstaturaEmpleado() {
		return estatura;
	}

	public void setEstatura(String estatura) {
		this.estatura = estatura;
	}

	public void mostrarDatos() {
		super.mostrarDatos();
		System.out.println(salario);
	}

	public int getSalario() {
		return salario;
	}

	public void setSalario(int salario) {
		this.salario = salario;
	}
	
}
