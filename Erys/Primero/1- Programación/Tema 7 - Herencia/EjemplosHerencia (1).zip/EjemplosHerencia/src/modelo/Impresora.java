package modelo;

public abstract class Impresora {
	private String fabricante;
	private int numSerie;
	private int numCartuchos;
	
	public abstract void conectar();
	
	public void imprimir() {
		System.out.println("Imprimiendo");
	}
}
