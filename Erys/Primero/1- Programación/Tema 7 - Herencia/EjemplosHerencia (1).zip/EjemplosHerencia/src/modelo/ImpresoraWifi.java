package modelo;

public class ImpresoraWifi extends Impresora {

	private String SSID;
	private String contrasena;
	
	@Override
	public void conectar() {
		// TODO Auto-generated method stub
		System.out.println("Conectar por Wifi al SSID " + SSID + " con contraseña" + contrasena);
		
	}

	public String getSSID() {
		return SSID;
	}

	public void setSSID(String sSID) {
		SSID = sSID;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

}
