package modelo;

public class ImpresoraUSB extends Impresora {

	private int numPuerto;
	
	@Override
	public void conectar() {
		// TODO Auto-generated method stub
		System.out.println("Conectando con el puerto USB COM" + numPuerto);
	}

	public int getNumPuerto() {
		return numPuerto;
	}

	public void setNumPuerto(int numPuerto) {
		this.numPuerto = numPuerto;
	}
}