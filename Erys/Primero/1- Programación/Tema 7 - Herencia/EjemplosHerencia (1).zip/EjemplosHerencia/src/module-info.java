/**
 * 
 */
/**
 * @author Ander
 *
 */
module EjemplosHerencia {
}