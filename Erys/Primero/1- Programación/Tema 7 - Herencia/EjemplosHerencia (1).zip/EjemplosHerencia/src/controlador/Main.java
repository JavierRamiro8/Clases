package controlador;

import modelo.Empleado;
import modelo.Impresora;
import modelo.ImpresoraUSB;
import modelo.ImpresoraWifi;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Empleado e = new Empleado("Ander", 25,"L",5);
		
		System.out.println(e.getNombre() + " - " + e.getEstaturaEmpleado());
		
		//Ejemplo Impresora
		ImpresoraWifi imp = new ImpresoraWifi();
		imp.setSSID("ARANGOYA");
		imp.setContrasena("1234");
		imp.conectar();
		imp.imprimir();
		
		ImpresoraUSB usb = new ImpresoraUSB();
		usb.setNumPuerto(5);
		usb.conectar();
		usb.imprimir();
		
	}

}
