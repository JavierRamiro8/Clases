package controlador;

import java.util.Arrays;

import modelo.Usuario;
import vista.IniciarSesion;
import vista.VentanaPrincipal;

public class Main {
	
	private static Usuario[] usuarios;
	private static int posicionUsuarioIniciado;
	private static IniciarSesion is;
	private static VentanaPrincipal vp;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		is = new IniciarSesion();
		is.setVisible(true);
	
	}
	
	public static void crearVentanaPrincipal(String nombreUsuario) {
		crearUsuario(nombreUsuario);
		
		is.dispose();
		vp = new VentanaPrincipal();
		vp.setVisible(true);
	}
	
	public static IniciarSesion getIs() {
		return is;
	}

	public static void setIs(IniciarSesion is) {
		Main.is = is;
	}

	public static VentanaPrincipal getVp() {
		return vp;
	}

	public static void setVp(VentanaPrincipal vp) {
		Main.vp = vp;
	}

	public static int getPosicionUsuarioIniciado() {
		return posicionUsuarioIniciado;
	}

	public static void setPosicionUsuarioIniciado(int posicionUsuarioIniciado) {
		Main.posicionUsuarioIniciado = posicionUsuarioIniciado;
	}

	public static Usuario[] getUsuarios() {
		return usuarios;
	}

	public static void setUsuarios(Usuario[] usuarios) {
		Main.usuarios = usuarios;
	}

	public static void crearUsuario(String nombre) {
		System.out.println("Nombre" + nombre);
		Usuario u = new Usuario(nombre);
		if (usuarios == null) {
			usuarios = new Usuario[1];
			usuarios[usuarios.length-1] = u;
		} else {
			usuarios = Arrays.copyOf(usuarios,usuarios.length+1);
			usuarios[usuarios.length-1] = u;
		}
		
		
		
		
	}
	
	public static void borrarUsuario(String nombreUsuario) {
		for (int i=0; i < usuarios.length; i++) {
	        if (usuarios[i].getNombre().equals(nombreUsuario) ) { //encontrado
				usuarios[i] = usuarios[usuarios.length - 1]; //copia el último en i
				usuarios = Arrays.copyOf(usuarios, usuarios.length - 1); //disminuimos la longitud de t 
				break;	
			}
		}
	}
}
