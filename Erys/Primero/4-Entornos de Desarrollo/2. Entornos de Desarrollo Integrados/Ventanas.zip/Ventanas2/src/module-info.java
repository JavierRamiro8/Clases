/**
 * 
 */
/**
 * @author Ander
 *
 */
module Ventanas2 {
	requires java.desktop;
}