/**
 * 
 */
/**
 * 
 */
module VentanaCelsiusFahrenheit02 {
	requires java.desktop;
}