package controlador;

import vista.ConversorCelsiusFahrenheit;

public class Main {

	private static ConversorCelsiusFahrenheit conversorCelsiusFahrenheit;
	
	public static void main(String[] args) {
		conversorCelsiusFahrenheit = new ConversorCelsiusFahrenheit();
		conversorCelsiusFahrenheit.setVisible(true);
	}

}
