package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ConversorCelsiusFahrenheit extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField FField;
	private JTextField CField;


	/**
	 * Create the frame.
	 */
	public ConversorCelsiusFahrenheit() {
		setTitle("Conversor Fahrenheit - Celsius");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 1.0, 0.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 0.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel FLabel = new JLabel("Fahrenheit");
		GridBagConstraints gbc_FLabel = new GridBagConstraints();
		gbc_FLabel.insets = new Insets(0, 0, 5, 5);
		gbc_FLabel.gridx = 1;
		gbc_FLabel.gridy = 1;
		contentPane.add(FLabel, gbc_FLabel);
		
		JLabel CLabel = new JLabel("Celsius");
		GridBagConstraints gbc_CLabel = new GridBagConstraints();
		gbc_CLabel.insets = new Insets(0, 0, 5, 5);
		gbc_CLabel.gridx = 3;
		gbc_CLabel.gridy = 1;
		contentPane.add(CLabel, gbc_CLabel);
		
		FField = new JTextField();
		FField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String valor = FField.getText();
				float numValor = Float.parseFloat(valor);
				float FarACel = (float) (numValor - 32) * 5f / 9f;
				String FarACelString = Float.toString(FarACel);
				CField.setText(FarACelString);
			}
		});
		GridBagConstraints gbc_fField = new GridBagConstraints();
		gbc_fField.insets = new Insets(0, 0, 5, 5);
		gbc_fField.fill = GridBagConstraints.HORIZONTAL;
		gbc_fField.gridx = 1;
		gbc_fField.gridy = 2;
		contentPane.add(FField, gbc_fField);
		FField.setColumns(10);
		
		CField = new JTextField();
		GridBagConstraints gbc_cField = new GridBagConstraints();
		gbc_cField.insets = new Insets(0, 0, 5, 5);
		gbc_cField.fill = GridBagConstraints.HORIZONTAL;
		gbc_cField.gridx = 3;
		gbc_cField.gridy = 2;
		contentPane.add(CField, gbc_cField);
		CField.setColumns(10);
		
		JButton botonReset = new JButton("Reset");
		botonReset.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				CField.setText("");
				FField.setText("");
			}
		});
		GridBagConstraints gbc_botonReset = new GridBagConstraints();
		gbc_botonReset.insets = new Insets(0, 0, 5, 5);
		gbc_botonReset.gridx = 2;
		gbc_botonReset.gridy = 4;
		contentPane.add(botonReset, gbc_botonReset);
		
		JButton botonCerrar = new JButton("Cerrar");
		botonCerrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		GridBagConstraints gbc_botonCerrar = new GridBagConstraints();
		gbc_botonCerrar.insets = new Insets(0, 0, 5, 5);
		gbc_botonCerrar.gridx = 3;
		gbc_botonCerrar.gridy = 4;
		contentPane.add(botonCerrar, gbc_botonCerrar);
	}

}
