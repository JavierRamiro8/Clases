/**
 * 
 */
/**
 * 
 */
module VentanaSaludar {
	requires java.desktop;
}