package controlador;

import vista.VentanaInicio;
import vista.VentanaSaludo;

public class Main {
	
	private static String nombre;
	private static VentanaInicio ventanaInicio;
	private static VentanaSaludo ventanaSaludo;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ventanaInicio = new VentanaInicio();
		ventanaInicio.setVisible(true);
		
	}
	
	
	
	public static void cargarVentanaSaludo() {
		
		ventanaSaludo = new VentanaSaludo();
		ventanaInicio.setVisible(false);
		ventanaSaludo.setVisible(true);
		
	}
	
	
	
	public static String getNombre() {
		return nombre;
	}


	public static void setNombre(String nombre) {
		Main.nombre = nombre;
	}

}
