package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BotonesIncrementales extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BotonesIncrementales frame = new BotonesIncrementales();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	int numVecesClic = 0;
	
	public BotonesIncrementales() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 1.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel contador = new JLabel("");
		GridBagConstraints gbc_contador = new GridBagConstraints();
		gbc_contador.insets = new Insets(0, 0, 5, 5);
		gbc_contador.gridx = 4;
		gbc_contador.gridy = 3;
		contentPane.add(contador, gbc_contador);
		
		JButton boton1 = new JButton("Incrementa 1 vez");
		boton1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				numVecesClic++;
				contador.setText("Veces que has hecho clic: " + numVecesClic);
			}
		});
		GridBagConstraints gbc_boton1 = new GridBagConstraints();
		gbc_boton1.insets = new Insets(0, 0, 5, 5);
		gbc_boton1.gridx = 4;
		gbc_boton1.gridy = 0;
		contentPane.add(boton1, gbc_boton1);
		
		JButton boton2 = new JButton("Incrementa 2 veces");
		boton2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				numVecesClic = numVecesClic + 2;
				contador.setText("Veces que has hecho clic: " + numVecesClic);
				
			}
		});
		GridBagConstraints gbc_boton2 = new GridBagConstraints();
		gbc_boton2.insets = new Insets(0, 0, 5, 5);
		gbc_boton2.gridx = 4;
		gbc_boton2.gridy = 1;
		contentPane.add(boton2, gbc_boton2);
	
	}

}
