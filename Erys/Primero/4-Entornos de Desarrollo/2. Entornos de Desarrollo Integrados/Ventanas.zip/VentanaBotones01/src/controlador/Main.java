package controlador;

import vista.BotonesIncrementales;

public class Main {
	
	private static BotonesIncrementales botonesIncrementales; 

	public static void main(String[] args) {
		botonesIncrementales = new BotonesIncrementales();
		botonesIncrementales.setVisible(true);

	}

}
