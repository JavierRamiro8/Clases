/**
 * 
 */
/**
 * 
 */
module VentanaBotones01 {
	requires java.desktop;
}