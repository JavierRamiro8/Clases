package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.DefaultComboBoxModel;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.CardLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.Component;
import javax.swing.Box;
import java.awt.Choice;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class VentanaLunas extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public VentanaLunas() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 232, 258);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel tituloFase = new JLabel("Selecciona una fase de la luna");
		tituloFase.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tituloFase.setBounds(36, 11, 149, 14);
		contentPane.add(tituloFase);
		
		JLabel lblMostrandoFase = new JLabel("Mostrando fase");
		lblMostrandoFase.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblMostrandoFase.setBounds(71, 71, 76, 14);
		contentPane.add(lblMostrandoFase);
		
		JLabel fase = new JLabel("");
		fase.setBounds(71, 96, 82, 83);
		contentPane.add(fase);
		
		JComboBox listaFases = new JComboBox();
		listaFases.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String seleccion = (String) listaFases.getSelectedItem();
				switch(seleccion) {
				case "Luna llena":
					ImageIcon img = new ImageIcon("images/full_moon.jpg");
					ImageIcon imgEscalada = new ImageIcon(img.getImage().getScaledInstance(fase.getWidth(), fase.getHeight(), Image.SCALE_SMOOTH));
					fase.setIcon(imgEscalada);
					break;
				case "Luna nueva":
					ImageIcon img2 = new ImageIcon("images/New_Moon.jpg");
					ImageIcon img2Escalada = new ImageIcon(img2.getImage().getScaledInstance(fase.getWidth(), fase.getHeight(), Image.SCALE_SMOOTH));
					fase.setIcon(img2Escalada);
					break;
				case "Luna creciente":
					ImageIcon img3 = new ImageIcon("images/creciente.jpg");
					ImageIcon img3Escalada = new ImageIcon(img3.getImage().getScaledInstance(fase.getWidth(), fase.getHeight(), Image.SCALE_SMOOTH));
					fase.setIcon(img3Escalada);
					break;
				case "Luna menguante":
					ImageIcon img4 = new ImageIcon("images/menguante.jpg");
					ImageIcon img4Escalada = new ImageIcon(img4.getImage().getScaledInstance(fase.getWidth(), fase.getHeight(), Image.SCALE_SMOOTH));
					fase.setIcon(img4Escalada);
					break;
				}
			}
		});
		listaFases.setBounds(61, 36, 108, 20);
		listaFases.setModel(new DefaultComboBoxModel(new String[] {"Luna nueva", "Luna llena", "Luna creciente", "Luna menguante"}));
		contentPane.add(listaFases);
		
		
		
		
		
		
	}
}
