/**
 * 
 */
/**
 * 
 */
module VentanasFasesLuna {
	requires java.desktop;
}