package controlador;

import vista.VentanaLunas;

public class Main {
	
	private static VentanaLunas vl;

	public static void main(String[] args) {
		vl = new VentanaLunas();
		vl.setVisible(true);

	}

}
