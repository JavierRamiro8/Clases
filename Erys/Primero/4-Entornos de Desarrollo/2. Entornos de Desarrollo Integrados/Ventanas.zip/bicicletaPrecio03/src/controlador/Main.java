package controlador;

import modelo.TipoBici;
import vista.VentanaBicis;
import vista.VentanaPrecio;

public class Main {

	private static VentanaBicis ventanaBicis;
	private static VentanaPrecio ventanaPrecio;
	private static String nombreCliente;
	private static int numDias;
	private static TipoBici tipoBici;
	private static boolean jubilado;
	private static boolean socio;
	private static float precio;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		ventanaBicis = new VentanaBicis();
		ventanaBicis.setVisible(true);

	}

	public static void cambio() {
		ventanaPrecio = new VentanaPrecio(nombreCliente, numDias, tipoBici, jubilado, socio, precio);
		ventanaPrecio.setVisible(true);
		ventanaBicis.setVisible(false);
	}
	
	public static void calcularPrecio(String pNombreCliente, int pNumDias, TipoBici pTipoBici, 
			boolean pJubilado, boolean pSocio) {
		
		float precioLocal = 0;
		nombreCliente = pNombreCliente;
		numDias = pNumDias;
		tipoBici = pTipoBici;
		jubilado = pJubilado;
		socio = pSocio;
		
		if (tipoBici.equals(TipoBici.MODELO1)) {
			precioLocal = 14;
		}else if (tipoBici.equals(TipoBici.MODELO2)) {
			precioLocal = 12;
		}else if (tipoBici.equals(TipoBici.MODELO3)) {
			precioLocal = 10;
		}

		if (numDias> 6 && numDias<10) {
			precioLocal =  numDias * precioLocal - (numDias* precioLocal /100 * 8);
		}else if (numDias>10) {
			precioLocal =  numDias * precioLocal  - ( numDias*precioLocal /100*15);
		} else {
			precioLocal  =  numDias * precioLocal ;
		}
		
		precio = precioLocal;
		cambio();
	}
}
