package modelo;

public enum TipoBici {
	MODELO1, MODELO2, MODELO3
}
