package controlador;

import java.util.Random;

import vista.VentanaNumerosAleatorios;

public class Main {
	private static VentanaNumerosAleatorios vna;

	public static void main(String[] args) {
		vna = new VentanaNumerosAleatorios();
		vna.setVisible(true);
	}
	
	
	
		public static String numRandom(int min, int max) {
			Random rand = new Random();
			int n = rand.nextInt(min, max);
			return String.valueOf(n);
		}

	}
	
	

