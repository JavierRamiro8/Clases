/**
 * 
 */
/**
 * 
 */
module VentanasNumerosAleatorios03 {
	requires java.desktop;
}