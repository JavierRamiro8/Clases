package controlador;

import vista.VentanaEjemplo;

public class Main {
	
	private static VentanaEjemplo ventanaEjemplo;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ventanaEjemplo = new VentanaEjemplo();
		ventanaEjemplo.setVisible(true);
		
		
	}

}
