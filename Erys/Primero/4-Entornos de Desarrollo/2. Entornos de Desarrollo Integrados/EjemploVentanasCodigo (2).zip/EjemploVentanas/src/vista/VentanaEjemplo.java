package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class VentanaEjemplo extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField introducirNombre;
	
	
	
	public VentanaEjemplo() {
		setTitle("EjemploVentanasSaludar");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 523, 388);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 297, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{4, 0, 15, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Aplicación para saludar");
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 2;
		gbc_panel.gridy = 2;
		contentPane.add(panel, gbc_panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("Introduce tu nombre:");
		panel.add(lblNewLabel_1, BorderLayout.CENTER);
		
		introducirNombre = new JTextField();
		GridBagConstraints gbc_introducirNombre = new GridBagConstraints();
		gbc_introducirNombre.insets = new Insets(0, 0, 5, 5);
		gbc_introducirNombre.fill = GridBagConstraints.HORIZONTAL;
		gbc_introducirNombre.gridx = 2;
		gbc_introducirNombre.gridy = 3;
		contentPane.add(introducirNombre, gbc_introducirNombre);
		introducirNombre.setColumns(10);
		
		JLabel textoSaludo = new JLabel("");
		GridBagConstraints gbc_textoSaludo = new GridBagConstraints();
		gbc_textoSaludo.insets = new Insets(0, 0, 5, 5);
		gbc_textoSaludo.gridx = 2;
		gbc_textoSaludo.gridy = 4;
		contentPane.add(textoSaludo, gbc_textoSaludo);
		
		JButton botonSaludar = new JButton("Saludame");
		botonSaludar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String nombre = introducirNombre.getText();
				textoSaludo.setText("Bienvenido, " + nombre);
				
			}
		});
		GridBagConstraints gbc_botonSaludar = new GridBagConstraints();
		gbc_botonSaludar.insets = new Insets(0, 0, 5, 5);
		gbc_botonSaludar.gridx = 2;
		gbc_botonSaludar.gridy = 5;
		contentPane.add(botonSaludar, gbc_botonSaludar);
	}

}
