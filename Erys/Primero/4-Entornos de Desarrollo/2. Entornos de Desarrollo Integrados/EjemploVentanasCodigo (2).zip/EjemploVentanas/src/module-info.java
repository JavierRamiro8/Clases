/**
 * 
 */
/**
 * 
 */
module EjemploVentanas {
	requires java.desktop;
}