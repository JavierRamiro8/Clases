package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelo.TipoBici;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;

public class VentanaPrecio extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public VentanaPrecio(String nombreCliente, int numDias, TipoBici tipoBici, boolean esJubilado, boolean esSocio, float precioValor) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 0;
		contentPane.add(panel_1, gbc_panel_1);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{0, 0, 0};
		gbl_panel_1.rowHeights = new int[]{0, 0};
		gbl_panel_1.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JLabel fxcvx = new JLabel("Nombre de cliente:");
		GridBagConstraints gbc_fxcvx = new GridBagConstraints();
		gbc_fxcvx.insets = new Insets(0, 0, 0, 5);
		gbc_fxcvx.gridx = 0;
		gbc_fxcvx.gridy = 0;
		panel_1.add(fxcvx, gbc_fxcvx);
		
		JLabel nombre = new JLabel(nombreCliente);
		GridBagConstraints gbc_nombre = new GridBagConstraints();
		gbc_nombre.gridx = 1;
		gbc_nombre.gridy = 0;
		panel_1.add(nombre, gbc_nombre);
		
		JPanel panel_2 = new JPanel();
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.insets = new Insets(0, 0, 5, 0);
		gbc_panel_2.fill = GridBagConstraints.BOTH;
		gbc_panel_2.gridx = 0;
		gbc_panel_2.gridy = 1;
		contentPane.add(panel_2, gbc_panel_2);
		GridBagLayout gbl_panel_2 = new GridBagLayout();
		gbl_panel_2.columnWidths = new int[]{0, 0, 0};
		gbl_panel_2.rowHeights = new int[]{0, 0};
		gbl_panel_2.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_2.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_2.setLayout(gbl_panel_2);
		
		JLabel fdsfsdfs = new JLabel("Número de días: ");
		GridBagConstraints gbc_fdsfsdfs = new GridBagConstraints();
		gbc_fdsfsdfs.insets = new Insets(0, 0, 0, 5);
		gbc_fdsfsdfs.gridx = 0;
		gbc_fdsfsdfs.gridy = 0;
		panel_2.add(fdsfsdfs, gbc_fdsfsdfs);
		
		JLabel dias = new JLabel(String.valueOf(numDias));
		GridBagConstraints gbc_dias = new GridBagConstraints();
		gbc_dias.gridx = 1;
		gbc_dias.gridy = 0;
		panel_2.add(dias, gbc_dias);
		
		JPanel panel_3 = new JPanel();
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.insets = new Insets(0, 0, 5, 0);
		gbc_panel_3.fill = GridBagConstraints.BOTH;
		gbc_panel_3.gridx = 0;
		gbc_panel_3.gridy = 2;
		contentPane.add(panel_3, gbc_panel_3);
		GridBagLayout gbl_panel_3 = new GridBagLayout();
		gbl_panel_3.columnWidths = new int[]{0, 0, 0};
		gbl_panel_3.rowHeights = new int[]{0, 0};
		gbl_panel_3.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_3.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_3.setLayout(gbl_panel_3);
		
		JLabel modeloTxt = new JLabel();
		modeloTxt.setText("Tipo bicicleta:");
		GridBagConstraints gbc_modeloTxt = new GridBagConstraints();
		gbc_modeloTxt.insets = new Insets(0, 0, 0, 5);
		gbc_modeloTxt.gridx = 0;
		gbc_modeloTxt.gridy = 0;
		panel_3.add(modeloTxt, gbc_modeloTxt);
		
		JLabel modelo = new JLabel(tipoBici.toString());
		GridBagConstraints gbc_modelo = new GridBagConstraints();
		gbc_modelo.gridx = 1;
		gbc_modelo.gridy = 0;
		panel_3.add(modelo, gbc_modelo);
		
		JPanel panel_4 = new JPanel();
		GridBagConstraints gbc_panel_4 = new GridBagConstraints();
		gbc_panel_4.insets = new Insets(0, 0, 5, 0);
		gbc_panel_4.fill = GridBagConstraints.BOTH;
		gbc_panel_4.gridx = 0;
		gbc_panel_4.gridy = 3;
		contentPane.add(panel_4, gbc_panel_4);
		GridBagLayout gbl_panel_4 = new GridBagLayout();
		gbl_panel_4.columnWidths = new int[]{0, 0, 0, 0, 0};
		gbl_panel_4.rowHeights = new int[]{0, 0};
		gbl_panel_4.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_4.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_4.setLayout(gbl_panel_4);
		
		JLabel citizenTxt = new JLabel("Senior Citizen:");
		GridBagConstraints gbc_citizenTxt = new GridBagConstraints();
		gbc_citizenTxt.insets = new Insets(0, 0, 0, 5);
		gbc_citizenTxt.gridx = 0;
		gbc_citizenTxt.gridy = 0;
		panel_4.add(citizenTxt, gbc_citizenTxt);
		
		String jubilado="";
		if(esJubilado) {
			jubilado = "Es jubilado.";
		} else {
			jubilado = "No es jubilado.";
		}		
		JLabel senior = new JLabel(jubilado);
		GridBagConstraints gbc_senior = new GridBagConstraints();
		gbc_senior.insets = new Insets(0, 0, 0, 5);
		gbc_senior.gridx = 1;
		gbc_senior.gridy = 0;
		panel_4.add(senior, gbc_senior);
		
		JLabel memberTxt = new JLabel("Member:");
		GridBagConstraints gbc_memberTxt = new GridBagConstraints();
		gbc_memberTxt.insets = new Insets(0, 0, 0, 5);
		gbc_memberTxt.gridx = 2;
		gbc_memberTxt.gridy = 0;
		panel_4.add(memberTxt, gbc_memberTxt);
		
		String socio="";
		if(esSocio) {
			socio = "Es socio.";
		} else {
			socio = "No es socio.";
		}
		JLabel member = new JLabel(socio);
		GridBagConstraints gbc_member = new GridBagConstraints();
		gbc_member.gridx = 3;
		gbc_member.gridy = 0;
		panel_4.add(member, gbc_member);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 4;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0};
		gbl_panel.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JLabel lblNewLabel_1 = new JLabel("Precio total:");
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 0;
		panel.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		JLabel precio = new JLabel(String.valueOf(precioValor));
		GridBagConstraints gbc_precio = new GridBagConstraints();
		gbc_precio.gridx = 1;
		gbc_precio.gridy = 0;
		panel.add(precio, gbc_precio);
	}

}
