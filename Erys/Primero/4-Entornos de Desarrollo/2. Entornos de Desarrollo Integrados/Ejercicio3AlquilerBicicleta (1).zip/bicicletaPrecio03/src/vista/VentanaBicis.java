package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controlador.Main;
import modelo.TipoBici;

import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JSpinner;

public class VentanaBicis extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField nombre;
	private TipoBici tipoBici;
	private JLabel foto;
	
	public VentanaBicis() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 469, 338);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JPanel panel_4 = new JPanel();
		GridBagConstraints gbc_panel_4 = new GridBagConstraints();
		gbc_panel_4.insets = new Insets(0, 0, 5, 0);
		gbc_panel_4.fill = GridBagConstraints.BOTH;
		gbc_panel_4.gridx = 0;
		gbc_panel_4.gridy = 0;
		contentPane.add(panel_4, gbc_panel_4);
		GridBagLayout gbl_panel_4 = new GridBagLayout();
		gbl_panel_4.columnWidths = new int[]{124, 0, 0};
		gbl_panel_4.rowHeights = new int[]{0, 0};
		gbl_panel_4.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel_4.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_4.setLayout(gbl_panel_4);
		
		JLabel customer = new JLabel("Customer Name: ");
		customer.setFont(new Font("Tahoma", Font.BOLD, 12));
		GridBagConstraints gbc_customer = new GridBagConstraints();
		gbc_customer.insets = new Insets(0, 0, 0, 5);
		gbc_customer.gridx = 0;
		gbc_customer.gridy = 0;
		panel_4.add(customer, gbc_customer);
		
		nombre = new JTextField();
		GridBagConstraints gbc_nombre = new GridBagConstraints();
		gbc_nombre.fill = GridBagConstraints.HORIZONTAL;
		gbc_nombre.gridx = 1;
		gbc_nombre.gridy = 0;
		panel_4.add(nombre, gbc_nombre);
		nombre.setColumns(10);
		
		JPanel panel_3 = new JPanel();
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.insets = new Insets(0, 0, 5, 0);
		gbc_panel_3.fill = GridBagConstraints.BOTH;
		gbc_panel_3.gridx = 0;
		gbc_panel_3.gridy = 1;
		contentPane.add(panel_3, gbc_panel_3);
		GridBagLayout gbl_panel_3 = new GridBagLayout();
		gbl_panel_3.columnWidths = new int[]{125, 0, 0};
		gbl_panel_3.rowHeights = new int[]{0, 0};
		gbl_panel_3.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel_3.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_3.setLayout(gbl_panel_3);
		
		JLabel diasText = new JLabel("Number of days:");
		diasText.setFont(new Font("Tahoma", Font.BOLD, 12));
		GridBagConstraints gbc_diasText = new GridBagConstraints();
		gbc_diasText.insets = new Insets(0, 0, 0, 5);
		gbc_diasText.gridx = 0;
		gbc_diasText.gridy = 0;
		panel_3.add(diasText, gbc_diasText);
		
		JSpinner numDias = new JSpinner();
		GridBagConstraints gbc_numDias = new GridBagConstraints();
		gbc_numDias.gridx = 1;
		gbc_numDias.gridy = 0;
		panel_3.add(numDias, gbc_numDias);
		
		JPanel panel_2 = new JPanel();
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.insets = new Insets(0, 0, 5, 0);
		gbc_panel_2.fill = GridBagConstraints.BOTH;
		gbc_panel_2.gridx = 0;
		gbc_panel_2.gridy = 2;
		contentPane.add(panel_2, gbc_panel_2);
		GridBagLayout gbl_panel_2 = new GridBagLayout();
		gbl_panel_2.columnWidths = new int[]{131, 0, 0, 0, 0};
		gbl_panel_2.rowHeights = new int[]{0, 0};
		gbl_panel_2.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_2.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_2.setLayout(gbl_panel_2);
		
		foto = new JLabel("");
		GridBagConstraints gbc_foto = new GridBagConstraints();
		gbc_foto.insets = new Insets(0, 0, 0, 5);
		gbc_foto.gridx = 0;
		gbc_foto.gridy = 0;
		panel_2.add(foto, gbc_foto);
		
		ButtonGroup g1 = new ButtonGroup();
		
		JRadioButton model2 = new JRadioButton("Model 2");
		model2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
					actualizarImagen("2.png");
					tipoBici = TipoBici.MODELO2;
			}
		});
		g1.add(model2); // IR LLAMANDO A LOS BOTONES
		JRadioButton Model1 = new JRadioButton("Model 1");
		Model1.setFont(new Font("Tahoma", Font.BOLD, 10));
		Model1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// IMAGENES
				actualizarImagen("1.jpg");
				tipoBici = TipoBici.MODELO1;
				
			}
		});
		g1.add(Model1);
		
		actualizarImagen("1.jpg");
		
		GridBagConstraints gbc_Model1 = new GridBagConstraints();
		gbc_Model1.insets = new Insets(0, 0, 0, 5);
		gbc_Model1.gridx = 1;
		gbc_Model1.gridy = 0;
		panel_2.add(Model1, gbc_Model1);
		model2.setFont(new Font("Tahoma", Font.BOLD, 10));
		GridBagConstraints gbc_model2 = new GridBagConstraints();
		gbc_model2.insets = new Insets(0, 0, 0, 5);
		gbc_model2.gridx = 2;
		gbc_model2.gridy = 0;
		panel_2.add(model2, gbc_model2);
		
		JRadioButton model3 = new JRadioButton("Model 3");
		model3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				actualizarImagen("3.png");
				tipoBici = TipoBici.MODELO3;
			}
		});
		g1.add(model3);
		model3.setFont(new Font("Tahoma", Font.BOLD, 10));
		GridBagConstraints gbc_model3 = new GridBagConstraints();
		gbc_model3.gridx = 3;
		gbc_model3.gridy = 0;
		panel_2.add(model3, gbc_model3);
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 3;
		contentPane.add(panel_1, gbc_panel_1);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{0, 0, 0};
		gbl_panel_1.rowHeights = new int[]{0, 0};
		gbl_panel_1.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JCheckBox checkCitizen = new JCheckBox("Senior Citizen");
		checkCitizen.setFont(new Font("Tahoma", Font.BOLD, 10));
		GridBagConstraints gbc_checkCitizen = new GridBagConstraints();
		gbc_checkCitizen.insets = new Insets(0, 0, 0, 5);
		gbc_checkCitizen.gridx = 0;
		gbc_checkCitizen.gridy = 0;
		panel_1.add(checkCitizen, gbc_checkCitizen);
		
		JCheckBox checkMember = new JCheckBox("Member");
		checkMember.setFont(new Font("Tahoma", Font.BOLD, 10));
		GridBagConstraints gbc_checkMember = new GridBagConstraints();
		gbc_checkMember.gridx = 1;
		gbc_checkMember.gridy = 0;
		panel_1.add(checkMember, gbc_checkMember);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 4;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{117, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JLabel total = new JLabel("Total:");
		total.setFont(new Font("Tahoma", Font.BOLD, 11));
		GridBagConstraints gbc_total = new GridBagConstraints();
		gbc_total.insets = new Insets(0, 0, 0, 5);
		gbc_total.gridx = 0;
		gbc_total.gridy = 0;
		panel.add(total, gbc_total);
		
		JButton Compute = new JButton("Compute");
		Compute.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String nombreCliente = nombre.getText();
				int numeroDias = (int) numDias.getValue();
				
				Main.calcularPrecio(nombreCliente, numeroDias, tipoBici, checkCitizen.isSelected(), checkMember.isSelected());
				
			}
		});
		Compute.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		GridBagConstraints gbc_Compute = new GridBagConstraints();
		gbc_Compute.fill = GridBagConstraints.BOTH;
		gbc_Compute.gridx = 1;
		gbc_Compute.gridy = 0;
		panel.add(Compute, gbc_Compute);		
		
	}
	
	public void actualizarImagen(String fotoSrc) {
		ImageIcon iconLogo = new ImageIcon("src/"+fotoSrc);
		Image image = iconLogo.getImage();
		Image scaledImage = image.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
		iconLogo = new ImageIcon(scaledImage);
		foto.setIcon(iconLogo);
	}

}
